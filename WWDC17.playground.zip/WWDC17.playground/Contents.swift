//: Playground - noun: a place where people can play

import UIKit
import PlaygroundSupport
import SpriteKit


struct Physics {
    
    static let bamboo : UInt32 = 1
    static let axe : UInt32 = 2
    static let panda : UInt32 = 3
    
}


class GameView: SKScene, SKPhysicsContactDelegate  {
    //declare my panda variables
    var panda : SKSpriteNode!
    
    override func didMove(to view: SKView) {
        
        physicsWorld.contactDelegate = self
        
        
        //TIMERS
        var timeBamboo = Timer.scheduledTimer(timeInterval: 2.0, target: self, selector: Selector("BambooSpawn"), userInfo: nil, repeats: true)
        
        var timeAxe = Timer.scheduledTimer(timeInterval: 0.5, target: self, selector: Selector("axespawn"), userInfo: nil, repeats: true)

        
        
        //sizing frame
        self.size = CGSize(width: 512, height: 512)
        
        self.backgroundColor = UIColor.white
        
        //initialise the panda
        panda = SKSpriteNode(imageNamed: "panda")
        panda.position = CGPoint(x: self.size.width / 2, y: self.size.height / 5)
        panda.size = CGSize(width: 60, height: 80)
        panda.zPosition = 10
        
        //PHYSICS
        panda.physicsBody = SKPhysicsBody(rectangleOf: panda.size)
        panda.physicsBody?.affectedByGravity = false
        panda.physicsBody?.categoryBitMask = Physics.panda
        panda.physicsBody?.contactTestBitMask = Physics.bamboo
        panda.physicsBody?.isDynamic = false
        
        
        self.addChild(panda)
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        if let touch = touches.first {
            let location = touch.location(in: self)
            
            panda.position.x = location.x
        }
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        if let touch = touches.first {
            let location = touch.location(in: self)
            
            panda.position.x = location.x
        }
    }
    
    
    func didBegin(_ contact: SKPhysicsContact) {
        var firstBody : SKPhysicsBody = contact.bodyA
        var secondBody : SKPhysicsBody = contact.bodyB
        
        if ((firstBody.categoryBitMask == Physics.bamboo) && (secondBody.categoryBitMask == Physics.axe) ||
            (firstBody.categoryBitMask == Physics.axe) && (secondBody.categoryBitMask == Physics.bamboo)){
            
            CollisionWithAxe(bamboo: firstBody.node as! SKSpriteNode, axe: secondBody.node as! SKSpriteNode)
        }
        
        else if ((firstBody.categoryBitMask == Physics.bamboo) && (secondBody.categoryBitMask == Physics.panda) ||
            (firstBody.categoryBitMask == Physics.panda) && (secondBody.categoryBitMask == Physics.bamboo)){
            
            CollisionWithAxe(bamboo: firstBody.node as! SKSpriteNode, axe: secondBody.node as! SKSpriteNode)
        }

    }
    
    
    func CollisionWithAxe(bamboo: SKSpriteNode, axe: SKSpriteNode){
        
        bamboo.removeFromParent()
        axe.removeFromParent()
    }
    
    func CollisionWithPanda(bamboo: SKSpriteNode, panda:SKSpriteNode){
        
        bamboo.removeFromParent()
        panda.removeFromParent()
    }
    
    func axespawn() {
        
        let axe = SKSpriteNode(imageNamed: "axe.png")
        axe.zPosition = -0.5
        axe.position = CGPoint(x: panda.position.x, y: panda.position.y)
        
        let action = SKAction.moveTo(y: self.size.height + 50, duration: 0.8)
        let actionDone = SKAction.removeFromParent()
        axe.run(SKAction.sequence([action, actionDone]))
        
        axe.physicsBody = SKPhysicsBody(rectangleOf: axe.size)
        axe.physicsBody?.categoryBitMask = Physics.panda
        axe.physicsBody?.contactTestBitMask = Physics.bamboo
        axe.physicsBody?.affectedByGravity = false
        axe.physicsBody?.isDynamic = false
        
        self.addChild(axe)
        
    }
    
    func BambooSpawn(){
        let bamboo = SKSpriteNode(imageNamed: "bamboo.png")
        let MinValue = self.size.width / 8
        let MaxValue = self.size.width - 20
        let Spawning = UInt32(MaxValue - MinValue)
        
        bamboo.position = CGPoint(x: CGFloat(arc4random_uniform(Spawning)), y: self.size.height)
        bamboo.size = CGSize(width: 60, height: 80)
        
        //BAMBOO ACTION
        let action = SKAction.moveTo(y: -50, duration: 5.0)
        let actionDone = SKAction.removeFromParent()
        bamboo.run(SKAction.sequence([action, actionDone]))
        
        
        
        bamboo.physicsBody = SKPhysicsBody(rectangleOf: bamboo.size)
        bamboo.physicsBody?.categoryBitMask = Physics.axe
        bamboo.physicsBody?.contactTestBitMask = Physics.axe
        bamboo.physicsBody?.affectedByGravity = false
        bamboo.physicsBody?.isDynamic = true
        
        
        
        self.addChild(bamboo)
    }
}
let frame = CGRect(x: 0, y: 0, width: 512, height: 512)
let scene = GameView()
let view = SKView(frame: frame)
view.presentScene(scene)
let page = PlaygroundPage.current
page.liveView = view
